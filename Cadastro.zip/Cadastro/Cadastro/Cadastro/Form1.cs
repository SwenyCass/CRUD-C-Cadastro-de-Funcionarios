﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cadastro
{
    public partial class CadastroFuncionarios : Form
    {

        string connectionString = "Data Source=DESKTOP-JEMAENV\\SQLEXPRESS;Initial Catalog=CadFuncionario;Integrated Security=True";

        public CadastroFuncionarios()
        {
            InitializeComponent();

        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {


            string sql = "INSERT INTO Funcionario (nome_funcionario, cargo, salario) values ('" + txtNome.Text + "' , '" + cbCargo.Text + "' ," + txtSalario.Text + ")";

            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            con.Open();

            try
            {
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                    MessageBox.Show("Cadastro realizado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                con.Close();
                DisplayData();
                ClearData();
            }
        }

        private void CadastroFuncionarios_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'cadFuncionarioDataSet.Funcionario'. Você pode movê-la ou removê-la conforme necessário.
            this.funcionarioTableAdapter.Fill(this.cadFuncionarioDataSet.Funcionario);

        }

        private void cbCargo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbCargo.Text != "")
            {
                txtIdFuncionario.Enabled = false;
                btnConsultar.Enabled = false;
                btnExcluir.Enabled = false;
            }
            else
            {
                txtIdFuncionario.Enabled = true;
                btnConsultar.Enabled = true;
                btnExcluir.Enabled = true;
            }
        }

        private void ClearData()
        {
            txtIdFuncionario.Text = "";
            txtNome.Text = "";
            cbCargo.Text = "";
            txtSalario.Text = "";
        }

        private void DisplayData()
        {
            SqlDataAdapter adapt;
            SqlConnection con = new SqlConnection(connectionString);
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Funcionario", con);
            adapt.Fill(dt);
            dgvFuncionario.DataSource = dt;
            con.Close();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {

            string sql = "UPDATE Funcionario SET nome_funcionario = '" + txtNome.Text + "', cargo = '" + cbCargo.Text + "' , salario = " + txtSalario.Text + " WHERE id_funcionario=" + txtIdFuncionario.Text;
           
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            con.Open();

            try
            {
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                    MessageBox.Show("Cadastro alterado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                con.Close();
                DisplayData();
                ClearData();
            }

            btnAdicionar.Enabled = true;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnConsultar.Enabled = true;
            txtIdFuncionario.Enabled = true;
            txtNome.Enabled = true;
            cbCargo.Enabled = true;
            txtSalario.Enabled = true;
            txtSalario.Enabled = true;
        }

        private void dgvFuncionario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM Funcionario WHERE id_funcionario =  " + txtIdFuncionario.Text;
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            con.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    btnAdicionar.Enabled = true;
                    btnAlterar.Enabled = true;
                    btnExcluir.Enabled = true;
                    btnConsultar.Enabled = true;
                    txtIdFuncionario.Enabled = false;
                    txtNome.Enabled = true;
                    cbCargo.Enabled = true;
                    txtSalario.Enabled = true;

                    txtIdFuncionario.Text = reader[0].ToString();
                    txtNome.Text = reader[1].ToString();
                    cbCargo.Text = reader[2].ToString();
                    txtSalario.Text = reader[3].ToString();
                }
                    
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                con.Close();
            }

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM Funcionario WHERE id_funcionario=" + txtIdFuncionario.Text;

            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            con.Open();

            try
            {
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                    MessageBox.Show("Exclusão realizada com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                con.Close();
                DisplayData();
                ClearData();
            }

            btnAdicionar.Enabled = true;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnConsultar.Enabled = true;
            txtIdFuncionario.Enabled = true;
            txtNome.Enabled = true;
            cbCargo.Enabled = true;
            txtSalario.Enabled = true;
 
        }

        private void txtIdFuncionario_TextChanged(object sender, EventArgs e)
        {
            if (txtIdFuncionario.Text != "")
            {
                txtNome.Enabled = false;
                cbCargo.Enabled = false;
                txtSalario.Enabled = false;
                btnAdicionar.Enabled = false;
                btnAlterar.Enabled = false;
                btnExcluir.Enabled = false;
            }
            else
            {
                txtNome.Enabled = true;
                cbCargo.Enabled = true;
                txtSalario.Enabled = true;
                btnAdicionar.Enabled = true;
                btnAlterar.Enabled = true;
                btnExcluir.Enabled = true;
            }
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
            if (txtNome.Text != "")
            {
                txtIdFuncionario.Enabled = false;
                btnConsultar.Enabled = false;
                btnExcluir.Enabled = false;
                if (txtIdFuncionario.Text == "")
                {
                    btnAlterar.Enabled = false;
                }
            }
            else
            {
                txtIdFuncionario.Enabled = true;
                btnConsultar.Enabled = true;
                btnExcluir.Enabled = true;
                btnAlterar.Enabled = true;
            }
        }

        private void txtSalario_TextChanged(object sender, EventArgs e)
        {
            if (txtSalario.Text != "")
            {
                txtIdFuncionario.Enabled = false;
                btnConsultar.Enabled = false;
                btnExcluir.Enabled = false;
            }
            else
            {
                txtIdFuncionario.Enabled = true;
                btnConsultar.Enabled = true;
                btnExcluir.Enabled = true;
            }
        }
    }

}        
    
